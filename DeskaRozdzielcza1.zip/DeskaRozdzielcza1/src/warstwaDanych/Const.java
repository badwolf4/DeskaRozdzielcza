package warstwaDanych;

public class Const {
	public static final String tablica ="dane";
	public static final String predkosc ="predkosc";
	public static final String przebieg_calkowity ="przebieg_calkowity";
	public static final String przebieg_dzienny ="przebieg_dzienny";
	public static final String lewy_kierunkowskaz ="lewy_kierunkowskaz";
	public static final String prawy_kierunkowskaz ="prawy_kierunkowskaz";
	public static final String kontrolka_swiatel_pozycyjnych ="kontrolka_swiatel_pozycyjnych";
	public static final String kontrolka_swiatel_mijania ="kontrolka_swiatel_mijania";
	public static final String kontrolka_swiatel_drogowych ="kontrolka_swiatel_drogowych";
	public static final String kontrolka_swiatel_przeciwmgielnych_przod ="kontrolka_swiatel_przeciwmgielnych_przod";
	public static final String kontrolka_swiatel_przeciwmgielnych_tyl ="kontrolka_swiatel_przeciwmgielnych_tyl";
	public static final String predkosc_srednia ="predkosc_srednia";
	public static final String predkosc_maksymalna ="predkosc_maksymalna";
	public static final String czas_podrozy ="czas_podrozy";
	public static final String dystans ="dystans";
	public static final String srednie_spalanie ="srednie_spalanie";
}
