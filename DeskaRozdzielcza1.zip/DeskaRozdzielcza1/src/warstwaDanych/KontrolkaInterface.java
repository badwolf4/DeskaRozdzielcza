package warstwaDanych;

public interface KontrolkaInterface {
	public void wyswietl();
	public void wlacz();
	public void wylacz();
	
}
